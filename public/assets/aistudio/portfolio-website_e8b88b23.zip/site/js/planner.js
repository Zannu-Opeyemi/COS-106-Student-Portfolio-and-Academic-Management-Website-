// Academic Planner: add, complete, delete tasks (array + DOM manipulation)
var tasks = [];
var STORE = "zoe_planner_tasks";

function load() {
  try { tasks = JSON.parse(localStorage.getItem(STORE)) || []; } catch (e) { tasks = []; }
}
function save() {
  try { localStorage.setItem(STORE, JSON.stringify(tasks)); } catch (e) {}
}

function addTask(title, course, due) {
  tasks.push({ id: Date.now(), title: title, course: course, due: due, done: false });
  save(); render();
}
function toggleTask(id) {
  tasks.forEach(function (t) { if (t.id === id) t.done = !t.done; });
  save(); render();
}
function deleteTask(id) {
  tasks = tasks.filter(function (t) { return t.id !== id; });
  save(); render();
}

function render() {
  var list = document.getElementById("task-list");
  list.innerHTML = "";
  if (tasks.length === 0) {
    var p = document.createElement("li");
    p.className = "empty";
    p.textContent = "No tasks yet. Add your first task above.";
    list.appendChild(p);
  }
  tasks.forEach(function (t) {
    var li = document.createElement("li");
    li.className = "task" + (t.done ? " done" : "");

    var cb = document.createElement("input");
    cb.type = "checkbox"; cb.checked = t.done;
    cb.setAttribute("aria-label", "Mark \"" + t.title + "\" as completed");
    cb.addEventListener("change", function () { toggleTask(t.id); });

    var info = document.createElement("div");
    info.className = "info";
    var title = document.createElement("span");
    title.className = "title"; title.textContent = t.title;
    var meta = document.createElement("small");
    var parts = [];
    if (t.course) parts.push(t.course);
    if (t.due) parts.push("Due " + t.due);
    meta.textContent = parts.join(" | ");
    info.appendChild(title); info.appendChild(meta);

    var del = document.createElement("button");
    del.className = "del"; del.type = "button"; del.textContent = "Delete";
    del.setAttribute("aria-label", "Delete \"" + t.title + "\"");
    del.addEventListener("click", function () { deleteTask(t.id); });

    li.appendChild(cb); li.appendChild(info); li.appendChild(del);
    list.appendChild(li);
  });
  var done = tasks.filter(function (t) { return t.done; }).length;
  document.getElementById("count-total").textContent = tasks.length;
  document.getElementById("count-done").textContent = done;
  document.getElementById("count-left").textContent = tasks.length - done;
}

document.addEventListener("DOMContentLoaded", function () {
  load(); render();
  var form = document.getElementById("task-form");
  var input = document.getElementById("task-title");
  var err = document.getElementById("task-error");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var title = input.value.trim();
    if (title === "") {
      err.textContent = "Enter a task name before adding.";
      input.classList.add("invalid"); input.focus(); return;
    }
    err.textContent = ""; input.classList.remove("invalid");
    addTask(title, document.getElementById("task-course").value.trim(), document.getElementById("task-due").value);
    form.reset(); input.focus();
  });
});
