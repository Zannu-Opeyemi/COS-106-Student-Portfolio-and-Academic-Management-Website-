// Shared: mobile menu toggle + footer year
document.addEventListener("DOMContentLoaded", function () {
  var btn = document.getElementById("menu-btn");
  var menu = document.getElementById("nav-menu");
  if (btn && menu) {
    btn.addEventListener("click", function () {
      var open = menu.classList.toggle("open");
      btn.setAttribute("aria-expanded", open);
    });
  }
  var yr = document.getElementById("year");
  if (yr) yr.textContent = new Date().getFullYear();
});
