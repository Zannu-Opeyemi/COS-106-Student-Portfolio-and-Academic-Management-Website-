// Contact form validation
var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
var digitsOnly = /^[0-9]+$/;

function setError(field, message) {
  document.getElementById(field.id + "-error").textContent = message;
  field.classList.toggle("invalid", message !== "");
  return message === "";
}

function validate(field) {
  var v = field.value.trim();
  if (v === "") return setError(field, "This field cannot be empty.");
  if (field.id === "email" && !emailPattern.test(v))
    return setError(field, "Enter a valid email address, like name@example.com.");
  if (field.id === "phone" && !digitsOnly.test(v))
    return setError(field, "Phone number must contain digits only (0-9).");
  return setError(field, "");
}

document.addEventListener("DOMContentLoaded", function () {
  var form = document.getElementById("contact-form");
  var fields = [].slice.call(form.querySelectorAll("input, textarea"));
  fields.forEach(function (f) {
    f.addEventListener("blur", function () { validate(f); });
    f.addEventListener("input", function () { if (f.classList.contains("invalid")) validate(f); });
  });
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var ok = true;
    fields.forEach(function (f) { if (!validate(f)) ok = false; });
    var box = document.getElementById("form-status");
    if (ok) {
      box.className = "success";
      box.textContent = "Thank you, " + document.getElementById("name").value.trim() + ". Your message has been sent.";
      form.reset();
    } else {
      box.className = "err";
      box.textContent = "Fix the highlighted fields and send again.";
      form.querySelector(".invalid").focus();
    }
  });
});
