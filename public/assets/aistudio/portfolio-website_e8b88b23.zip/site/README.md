# Zannu Opeyemi Emmanuel - Portfolio (COS 106 Term Project)
Pages: index, about, projects, planner, contact. Open index.html to view locally.
Host free on GitHub Pages / Netlify / Vercel by uploading this folder.
